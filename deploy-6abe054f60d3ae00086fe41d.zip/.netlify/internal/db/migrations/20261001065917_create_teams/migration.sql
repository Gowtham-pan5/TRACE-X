CREATE TABLE "teams" (
	"id" serial PRIMARY KEY,
	"team_key" text NOT NULL UNIQUE,
	"team" text NOT NULL,
	"members" text DEFAULT '' NOT NULL,
	"r1_score" integer DEFAULT 0 NOT NULL,
	"r1_time" integer DEFAULT 0 NOT NULL,
	"r1_answers" jsonb,
	"status" text DEFAULT 'waiting' NOT NULL,
	"created_at" timestamp DEFAULT now(),
	"updated_at" timestamp DEFAULT now()
);
