import { pgTable, serial, text, timestamp, integer, jsonb } from "drizzle-orm/pg-core";

// One row per team. status: waiting -> approved | rejected (set by admin after Round 1)
export const teams = pgTable("teams", {
  id: serial().primaryKey(),
  teamKey: text("team_key").notNull().unique(),
  team: text().notNull(),
  members: text().notNull().default(""),
  r1Score: integer("r1_score").notNull().default(0),
  r1Time: integer("r1_time").notNull().default(0),
  r1Answers: jsonb("r1_answers"),
  status: text().notNull().default("waiting"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});
