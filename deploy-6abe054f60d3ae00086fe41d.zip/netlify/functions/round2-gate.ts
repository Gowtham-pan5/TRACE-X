import type { Config } from "@netlify/functions";
import { asc, eq } from "drizzle-orm";
import { timingSafeEqual } from "node:crypto";
import { db } from "../../db/index.js";
import { teams } from "../../db/schema.js";

const STATUSES = ["waiting", "approved", "rejected"];
const keyOf = (name: string) => name.trim().toLowerCase();
const clean = (v: unknown, max: number) => String(v ?? "").trim().slice(0, max);

function isAdmin(req: Request) {
  const pin = process.env.ADMIN_PIN || "";
  const given = req.headers.get("x-admin-pin") || "";
  if (!pin || given.length !== pin.length) return false;
  return timingSafeEqual(Buffer.from(given), Buffer.from(pin));
}

export default async (req: Request) => {
  const url = new URL(req.url);
  const isAdminRoute = url.pathname.startsWith("/api/admin/");

  if (isAdminRoute) {
    if (!process.env.ADMIN_PIN) return Response.json({ error: "ADMIN_PIN is not set on the site" }, { status: 503 });
    if (!isAdmin(req)) return Response.json({ error: "Wrong PIN" }, { status: 401 });

    if (req.method === "GET") {
      const rows = await db.select().from(teams).orderBy(asc(teams.createdAt));
      return Response.json(rows);
    }
    if (req.method === "POST") {
      const body = await req.json().catch(() => ({}));
      const status = clean(body.status, 20);
      if (!STATUSES.includes(status)) return Response.json({ error: "Bad status" }, { status: 400 });
      if (body.allWaiting) {
        await db.update(teams).set({ status, updatedAt: new Date() }).where(eq(teams.status, "waiting"));
      } else {
        const team = clean(body.team, 30);
        if (!team) return Response.json({ error: "Team required" }, { status: 400 });
        await db.update(teams).set({ status, updatedAt: new Date() }).where(eq(teams.teamKey, keyOf(team)));
      }
      return Response.json({ ok: true });
    }
    if (req.method === "DELETE") {
      const team = url.searchParams.get("team");
      if (team) await db.delete(teams).where(eq(teams.teamKey, keyOf(team)));
      else await db.delete(teams);
      return Response.json({ ok: true });
    }
    return new Response("Method not allowed", { status: 405 });
  }

  // Student routes
  if (req.method === "POST") {
    const body = await req.json().catch(() => ({}));
    const team = clean(body.team, 30);
    if (team.length < 2) return Response.json({ error: "Team required" }, { status: 400 });
    const r1Score = Math.max(0, Math.min(50, Math.round(Number(body.r1Score) || 0)));
    const r1Time = Math.max(0, Math.round(Number(body.r1Time) || 0));
    const values = {
      teamKey: keyOf(team),
      team,
      members: clean(body.members, 200),
      r1Score,
      r1Time,
      r1Answers: Array.isArray(body.r1Answers) ? body.r1Answers.slice(0, 10) : null,
    };
    // A team that was already approved/rejected keeps the admin's decision
    const [row] = await db
      .insert(teams)
      .values(values)
      .onConflictDoUpdate({ target: teams.teamKey, set: { ...values, updatedAt: new Date() } })
      .returning();
    return Response.json({ status: row.status });
  }

  if (req.method === "GET") {
    const team = clean(url.searchParams.get("team"), 30);
    const [row] = await db.select({ status: teams.status }).from(teams).where(eq(teams.teamKey, keyOf(team)));
    return Response.json({ status: row?.status ?? "unknown" });
  }

  return new Response("Method not allowed", { status: 405 });
};

export const config: Config = {
  path: ["/api/round1", "/api/admin/teams"],
};
